package com.louis.feature_info

import android.os.Bundle
import com.louis.core.arch.BaseActivity

/**
 * Sample page
 */
class DramaInfoActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product)
    }
}