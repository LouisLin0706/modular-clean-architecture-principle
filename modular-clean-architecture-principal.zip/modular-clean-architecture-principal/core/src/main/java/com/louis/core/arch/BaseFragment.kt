package com.louis.core.arch

import android.support.v4.app.DialogFragment

open class BaseFragment : DialogFragment() {
}