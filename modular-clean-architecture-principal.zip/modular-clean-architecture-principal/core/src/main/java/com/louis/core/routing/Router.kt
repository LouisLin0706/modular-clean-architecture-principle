package com.louis.core.routing

import android.content.Context

interface FeatureHomeRouter {
    fun showFeatureHome(context: Context)
}

interface FeatureInfoRouter {
    fun showProductInfo(context: Context)
}