package com.louis.core.data.model

import android.support.v4.app.Fragment

class TabFragmentWrapper(val fragment: Fragment, val title: String)