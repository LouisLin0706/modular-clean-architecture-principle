package com.louis.core.arch

import android.support.v7.app.AppCompatActivity

open class BaseActivity : AppCompatActivity() {
}