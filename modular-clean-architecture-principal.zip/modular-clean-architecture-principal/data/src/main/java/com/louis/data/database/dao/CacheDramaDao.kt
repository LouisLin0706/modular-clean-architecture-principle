package com.louis.data.database.dao

import android.arch.persistence.room.Dao

@Dao
abstract class CacheDramaDao {

}