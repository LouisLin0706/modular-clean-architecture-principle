package com.louis.data.database.drama

import android.arch.persistence.room.Database
import android.arch.persistence.room.RoomDatabase
import com.louis.data.database.dao.CacheDramaDao
import com.louis.data.database.drama.model.CacheDrama

@Database(entities = [CacheDrama::class], version = 1)
abstract class DramaDatabase : RoomDatabase() {

    abstract fun cacheDramaDao(): CacheDramaDao

    companion object {
        const val TABLE_NAME = "DramaTable"
    }
}