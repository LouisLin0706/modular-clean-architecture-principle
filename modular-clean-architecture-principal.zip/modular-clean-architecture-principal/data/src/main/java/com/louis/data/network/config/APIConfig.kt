package com.louis.data.network.config

import com.louis.data.BuildConfig

class APIConfig {
    companion object {
        const val DOMAIN_API = BuildConfig.DOMAIN_API
        const val PATH_DRAMAS = "/v2/5a97c59c30000047005c1ed2"
    }
}